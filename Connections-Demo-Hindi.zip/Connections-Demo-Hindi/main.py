import csv
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_cors import CORS
import random
import os
import time
from categories import all_categories, all_hindi_sets, get_ordered_categories

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a real secret key for production

DATA_FILE = 'game_data.csv'
# Create the CSV file if it doesn't exist
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Name', 'Age', 'Profession', 'Start Time', 'Categories', 'Completed', 'Mistakes'])


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Save user data in session
        session['user_data'] = {
            'name': request.form['name'],
            'age': request.form['age'],
            'profession': request.form['profession'],
            'start_time': time.time()
        }
        return redirect(url_for('game'))
    return render_template('register.html')

@app.route('/game')
def game():
    user_data = session.get('user_data', {})
    user_key = f"{user_data.get('name')}_{user_data.get('age')}_{user_data.get('profession')}"
    
    # Initialize or get completed sets for this user
    if 'completed_sets' not in session:
        session['completed_sets'] = {}
    if user_key not in session['completed_sets']:
        session['completed_sets'][user_key] = []
        
    # Get available sets (sets not yet completed by this user)
    completed_set_indices = session['completed_sets'][user_key]
    available_sets = [i for i in range(len(all_hindi_sets)) if i not in completed_set_indices]
    
    # If all sets completed, reset the completed sets
    if not available_sets:
        session['completed_sets'][user_key] = []
        available_sets = list(range(len(all_hindi_sets)))
    
    # Select a random available set
    set_index = random.choice(available_sets)
    selected_set = all_hindi_sets[set_index]
    session['current_set_index'] = set_index
    
    # Get categories from selected set
    all_categories = get_ordered_categories(selected_set)
    selected_categories = list(all_categories.keys())
    # Store categories in session for game over display
    session['game_categories'] = {
        'yellow': selected_categories[0],
        'green': selected_categories[1],
        'blue': selected_categories[2],
        'purple': selected_categories[3]
    }
    session['category_words'] = {
        selected_categories[0]: all_categories[selected_categories[0]],
        selected_categories[1]: all_categories[selected_categories[1]],
        selected_categories[2]: all_categories[selected_categories[2]],
        selected_categories[3]: all_categories[selected_categories[3]]
    }
    # Select words from these categories
    words = []
    for category in selected_categories:
        words.extend(random.sample(all_categories[category], 4))
    # Shuffle the words to mix the categories
    random.shuffle(words)

    # Initialize for a new game
    session['used_colors'] = []
    session['category_colors'] = {}
    session.pop('mistakes', None)  # Properly reset the 'mistakes' counter
    session['mistakes'] = 4
    session['already_guessed'] = []  # Initialize the already_guessed list
    session['grid'] = [words[i:i + 4] for i in range(0, 16, 4)]
    return render_template('index.html', grid=session['grid'])

@app.route('/submit_guess', methods=['POST'])
def submit_guess():
  data = request.get_json()
  selected_words = data.get('selectedWords', [])
  if not selected_words:
    return jsonify({'result': 'error', 'message': 'No words selected'})

  already_guessed = session.get('already_guessed', [])
  selected_words_set = frozenset(selected_words)

  if selected_words_set in map(
      frozenset, already_guessed
  ):  # Use map to ensure we compare correctly between list of lists and set
    return jsonify({
        'result': 'error',
        'message': 'Words have already been guessed!',
        'alreadyGuessed': True,
        'disableSubmit': True
    })

  # Get categories for current game session
  game_categories = session.get('category_words', {})
  
  first_word_category = None
  for category, words in game_categories.items():
    if selected_words[0] in words:
      first_word_category = category
      break

  if not first_word_category:
    return jsonify({
        'result': 'error',
        'message': 'Something went wrong, please try again'
    })

  all_correct = all(word in game_categories[first_word_category]
                    for word in selected_words)

  if not all_correct:
    session['mistakes'] = session.get('mistakes', 4) - 1
    already_guessed.append(selected_words)
    session['already_guessed'] = already_guessed
    
    # Calculate how many words are correct
    correct_count = sum(1 for word in selected_words if word in game_categories[first_word_category])
    message = "Try again!"
    if correct_count == 3:
        message = "Try again! Hint: 3 out of 4 words are correct"
    
    return jsonify({
      'result': 'failure',
      'message': message,
      'mistakes': session['mistakes'],
      'alreadyGuessed': False
    })
  else:
    # All words are in the same category, so handle the color assignment
    if first_word_category not in session['category_colors']:
      # Get difficulty level from categories
      difficulty_colors = {
          0: 'yellow',  # Easiest
          1: 'green',   # Medium-Easy
          2: 'blue',    # Difficult
          3: 'purple'   # Most Difficult
      }
      # Get index of category to determine difficulty (0-3)
      categories_list = list(game_categories.keys())
      difficulty_level = categories_list.index(first_word_category)
      color = difficulty_colors[difficulty_level]
      session['used_colors'].append(color)
      session['category_colors'][first_word_category] = color
  color = session['category_colors'][first_word_category]

  # Store the correct guess in the session
  already_guessed.append(selected_words_set)
  session['already_guessed'] = [list(guess) for guess in already_guessed]

  response = jsonify({
      'result': 'success',
      'message': 'Yay! Category: ' + first_word_category,
      'color': color,
      'category': first_word_category,
      'words': game_categories[first_word_category],
      'alreadyGuessed': False
  })
  
  # If this was the last category (all categories found)
  if len(session.get('category_colors', {})) == 4:
      save_game_data(completed=True)
  elif session.get('mistakes', 0) == 0:
      save_game_data(completed=False)
      
  return response

def save_game_data(completed):
    user_data = session.get('user_data')
    if user_data:
        categories = session.get('game_categories', {})
        
        # If game completed successfully, add to completed sets
        if completed:
            user_key = f"{user_data.get('name')}_{user_data.get('age')}_{user_data.get('profession')}"
            if 'completed_sets' not in session:
                session['completed_sets'] = {}
            if user_key not in session['completed_sets']:
                session['completed_sets'][user_key] = []
            current_set_index = session.get('current_set_index')
            if current_set_index not in session['completed_sets'][user_key]:
                session['completed_sets'][user_key].append(current_set_index)
        mistakes = 4 - session.get('mistakes', 0)
        end_time = time.time()
        duration = end_time - user_data['start_time']
        total_guesses = len(session.get('already_guessed', []))
        correct_guesses = len(session.get('category_colors', {}))
        accuracy = (correct_guesses / total_guesses) * 100 if total_guesses > 0 else 0
        
        with open(DATA_FILE, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([
                user_data['name'], 
                user_data['age'], 
                user_data['profession'],
                user_data['start_time'],
                str(categories),
                completed,
                mistakes,
                duration,
                total_guesses,
                correct_guesses,
                accuracy
            ])

if __name__ == '__main__':
  app.run(debug=True, port=5001, host='0.0.0.0')
@app.route('/stats')
def stats():
    stats_data = []
    with open(DATA_FILE, 'r') as csvfile:
        reader = csv.DictReader(csvfile, fieldnames=[
            'name', 'age', 'profession', 'start_time', 'categories', 
            'completed', 'mistakes', 'duration', 'total_guesses',
            'correct_guesses', 'accuracy'
        ])
        next(reader)  # Skip header
        for row in reader:
            stats_data.append(row)
    
    return render_template('stats.html', stats=stats_data)
